# 图片资源说明

为了减小初次上传体积，这里只包含3张示例图片。

完整图片包（11张）你可以：
1. 通过 GitHub Desktop 客户端上传
2. 或分批上传剩余图片
3. 或使用图片CDN（推荐）

使用GitHub Desktop上传剩余图片：
1. 下载 GitHub Desktop：https://desktop.github.com
2. 打开这个仓库
3. 把剩余的图片拖拽到 images/ 文件夹
4. 提交并推送
